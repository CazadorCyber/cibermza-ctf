# event-minisite

Template para congresos ficticios, ideal para demos y tests internos.
Basado en diseño responsive. Incluye integración a Google Forms.

Autor: J.Lopez  
Correo: javierlopez.research@protonmail.com

Creado: junio 2025
